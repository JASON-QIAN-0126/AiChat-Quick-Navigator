// src/content/siteAdapters/chatgptAdapter.ts
var chatgptAdapter = {
  name: "ChatGPT",
  /**
   * 判断是否是 ChatGPT 对话页面
   */
  isSupported(location) {
    const { hostname, pathname } = location;
    const isChatGPT = hostname === "chatgpt.com" || hostname === "chat.openai.com";
    const isConversationPage = pathname === "/" || pathname.startsWith("/c/");
    return isChatGPT && isConversationPage;
  },
  /**
   * 在 ChatGPT 页面中查找所有 AI 回答节点
   * 
   * ChatGPT 的 DOM 结构说明：
   * - AI 回答通常在一个包含特定 data-* 属性的 div 中
   * - 可以通过 data-message-author-role="assistant" 来识别
   * - 或者通过其他特征来识别（可能需要根据实际页面结构调整）
   */
  findAllAnswers(root) {
    const answers = [];
    const foundMethods = [];
    const messageElements = root.querySelectorAll('[data-message-author-role="assistant"]');
    if (messageElements.length > 0) {
      foundMethods.push(`data-message-author-role (${messageElements.length})`);
      messageElements.forEach((el) => {
        if (el instanceof HTMLElement) {
          answers.push(el);
        }
      });
    }
    if (answers.length === 0) {
      const conversationTurns = root.querySelectorAll('[data-testid^="conversation-turn"]');
      conversationTurns.forEach((turn) => {
        if (turn instanceof HTMLElement) {
          const hasAssistant = turn.querySelector('[data-message-author-role="assistant"]') || turn.textContent?.includes("ChatGPT") || turn.querySelector(".bg-\\[\\#f7f7f8\\]");
          if (hasAssistant) {
            answers.push(turn);
          }
        }
      });
      if (answers.length > 0) {
        foundMethods.push(`conversation-turn (${answers.length})`);
      }
    }
    if (answers.length === 0) {
      const allTurns = root.querySelectorAll('main [class*="group"]');
      allTurns.forEach((turn, index) => {
        if (turn instanceof HTMLElement) {
          const hasGrayBg = window.getComputedStyle(turn).backgroundColor.includes("247, 247, 248");
          if (index % 2 === 1 || hasGrayBg) {
            answers.push(turn);
          }
        }
      });
      if (answers.length > 0) {
        foundMethods.push(`structure-based (${answers.length})`);
      }
    }
    if (answers.length > 0) {
      console.log(`\u2705 ChatGPT Adapter: \u627E\u5230 ${answers.length} \u4E2A AI \u56DE\u7B54\u8282\u70B9 [\u65B9\u6CD5: ${foundMethods.join(", ")}]`);
      console.log("\u7B2C\u4E00\u4E2A\u56DE\u7B54\u8282\u70B9:", {
        tag: answers[0].tagName,
        classes: answers[0].className,
        dataAttrs: Array.from(answers[0].attributes).filter((attr) => attr.name.startsWith("data-")).map((attr) => `${attr.name}="${attr.value}"`)
      });
    } else {
      console.warn("\u26A0\uFE0F ChatGPT Adapter: \u672A\u627E\u5230\u4EFB\u4F55 AI \u56DE\u7B54\u8282\u70B9\uFF0C\u8BF7\u68C0\u67E5\u9875\u9762\u7ED3\u6784");
    }
    return answers;
  }
};

// src/content/siteAdapters/index.ts
var adapters = [
  chatgptAdapter
  // 未来可以在这里添加更多适配器，例如：
  // claudeAdapter,
  // geminiAdapter,
];
function getActiveAdapter(location) {
  for (const adapter of adapters) {
    if (adapter.isSupported(location)) {
      return adapter;
    }
  }
  return null;
}

// src/content/navigation/answerIndexManager.ts
var AnswerIndexManager = class {
  constructor(adapter, root) {
    this.answers = [];
    this.currentIndex = 0;
    this.adapter = adapter;
    this.root = root;
    this.refresh();
  }
  /**
   * 刷新回答列表
   * 重新查找所有回答节点并更新索引
   */
  refresh() {
    const nodes = this.adapter.findAllAnswers(this.root);
    this.answers = nodes.map((node) => ({
      domNode: node,
      topOffset: this.getTopOffset(node)
    }));
    this.answers.sort((a, b) => a.topOffset - b.topOffset);
  }
  /**
   * 计算元素相对于文档顶部的偏移量
   */
  getTopOffset(element) {
    const rect = element.getBoundingClientRect();
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    return rect.top + scrollTop;
  }
  /**
   * 获取回答总数
   */
  getTotalCount() {
    return this.answers.length;
  }
  /**
   * 获取当前索引（从 0 开始）
   */
  getCurrentIndex() {
    return this.currentIndex;
  }
  /**
   * 设置当前索引
   * @param index - 新的索引值（从 0 开始）
   */
  setCurrentIndex(index) {
    if (this.answers.length === 0) {
      this.currentIndex = 0;
      return;
    }
    if (index < 0) {
      this.currentIndex = 0;
    } else if (index >= this.answers.length) {
      this.currentIndex = this.answers.length - 1;
    } else {
      this.currentIndex = index;
    }
  }
  /**
   * 获取指定索引的节点
   * @param index - 索引值（从 0 开始）
   * @returns 对应的节点，如果索引无效则返回 null
   */
  getNodeByIndex(index) {
    if (index < 0 || index >= this.answers.length) {
      return null;
    }
    return this.answers[index].domNode;
  }
  /**
   * 获取当前节点
   */
  getCurrentNode() {
    return this.getNodeByIndex(this.currentIndex);
  }
  /**
   * 跳转到上一个回答
   * @returns 是否成功跳转（如果已经是第一个则返回 false）
   */
  moveToPrev() {
    if (this.currentIndex > 0) {
      this.setCurrentIndex(this.currentIndex - 1);
      return true;
    }
    return false;
  }
  /**
   * 跳转到下一个回答
   * @returns 是否成功跳转（如果已经是最后一个则返回 false）
   */
  moveToNext() {
    if (this.currentIndex < this.answers.length - 1) {
      this.setCurrentIndex(this.currentIndex + 1);
      return true;
    }
    return false;
  }
  /**
   * 根据当前滚动位置更新当前索引
   * @param scrollY - 当前滚动位置（window.scrollY）
   */
  updateCurrentIndexByScroll(scrollY) {
    if (this.answers.length === 0) {
      return;
    }
    const windowHeight = window.innerHeight;
    const documentHeight = document.documentElement.scrollHeight;
    const scrollBottom = scrollY + windowHeight;
    const isNearBottom = documentHeight - scrollBottom < 200;
    if (isNearBottom) {
      this.currentIndex = this.answers.length - 1;
      return;
    }
    const viewportCenter = scrollY + windowHeight / 2;
    let closestIndex = 0;
    let minDistance = Math.abs(this.answers[0].topOffset - viewportCenter);
    for (let i = 1; i < this.answers.length; i++) {
      const distance = Math.abs(this.answers[i].topOffset - viewportCenter);
      if (distance < minDistance) {
        minDistance = distance;
        closestIndex = i;
      } else if (this.answers[i].topOffset > viewportCenter) {
        break;
      }
    }
    this.currentIndex = closestIndex;
  }
  /**
   * 检查是否需要刷新回答列表
   * 如果页面上的回答数量发生变化，返回 true
   */
  needsRefresh() {
    const currentNodes = this.adapter.findAllAnswers(this.root);
    return currentNodes.length !== this.answers.length;
  }
};

// src/content/navigation/themes.ts
var themes = {
  green: {
    name: "\u7EFF\u8272",
    primary: "#4CAF50",
    primaryHover: "#45a049",
    primaryActive: "#3d8b40",
    border: "#4CAF50",
    background: "rgba(255, 255, 255, 0.95)",
    textColor: "#333",
    highlightBorder: "#4CAF50",
    highlightBackground: "rgba(76, 175, 80, 0.1)"
  },
  lavender: {
    name: "\u85B0\u8863\u8349\u7D2B",
    primary: "#9C88FF",
    primaryHover: "#8B76EE",
    primaryActive: "#7A65DD",
    border: "#9C88FF",
    background: "rgba(255, 255, 255, 0.95)",
    textColor: "#333",
    highlightBorder: "#9C88FF",
    highlightBackground: "rgba(156, 136, 255, 0.1)"
  },
  dark: {
    name: "\u6697\u8272",
    primary: "#6B7280",
    primaryHover: "#4B5563",
    primaryActive: "#374151",
    border: "#4B5563",
    background: "rgba(30, 30, 30, 0.95)",
    textColor: "#E5E7EB",
    highlightBorder: "#6B7280",
    highlightBackground: "rgba(107, 114, 128, 0.15)"
  },
  light: {
    name: "\u4EAE\u8272",
    primary: "#3B82F6",
    primaryHover: "#2563EB",
    primaryActive: "#1D4ED8",
    border: "#3B82F6",
    background: "rgba(255, 255, 255, 0.98)",
    textColor: "#1F2937",
    highlightBorder: "#3B82F6",
    highlightBackground: "rgba(59, 130, 246, 0.1)"
  }
};
function getDefaultTheme() {
  if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
    return "dark";
  }
  return "green";
}
var DEFAULT_THEME = getDefaultTheme();

// src/content/navigation/navigatorUI.ts
var NavigatorUI = class {
  constructor() {
    this.onPrevCallback = null;
    this.onNextCallback = null;
    this.currentIndex = 0;
    this.totalCount = 0;
    this.currentTheme = getDefaultTheme();
    this.isHidden = false;
    this.container = this.createContainer();
    this.prevButton = this.createButton("\u2191", "\u4E0A\u4E00\u6761\u56DE\u7B54");
    this.nextButton = this.createButton("\u2193", "\u4E0B\u4E00\u6761\u56DE\u7B54");
    this.indexDisplay = this.createIndexDisplay();
    this.setupUI();
    this.attachToPage();
    this.loadTheme();
  }
  /**
   * 创建容器元素
   */
  createContainer() {
    const container = document.createElement("div");
    container.id = "llm-answer-navigator";
    container.style.cssText = `
      position: fixed;
      bottom: 30px;
      right: 30px;
      z-index: 99999;
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding: 12px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      backdrop-filter: blur(10px);
      transition: all 0.3s ease;
    `;
    return container;
  }
  /**
   * 创建按钮
   */
  createButton(text, title) {
    const button = document.createElement("button");
    button.textContent = text;
    button.title = title;
    button.dataset.originalTitle = title;
    button.style.cssText = `
      padding: 8px 16px;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 18px;
      font-weight: bold;
      transition: all 0.2s ease;
      user-select: none;
    `;
    return button;
  }
  /**
   * 创建索引显示元素
   */
  createIndexDisplay() {
    const display = document.createElement("span");
    display.style.cssText = `
      text-align: center;
      font-size: 14px;
      font-weight: 500;
      padding: 4px 0;
      user-select: none;
    `;
    return display;
  }
  /**
   * 组装 UI
   */
  setupUI() {
    this.prevButton.addEventListener("click", () => {
      if (this.onPrevCallback) {
        this.onPrevCallback();
      }
    });
    this.nextButton.addEventListener("click", () => {
      if (this.onNextCallback) {
        this.onNextCallback();
      }
    });
    this.container.appendChild(this.prevButton);
    this.container.appendChild(this.indexDisplay);
    this.container.appendChild(this.nextButton);
    this.updateDisplay();
  }
  /**
   * 将 UI 添加到页面
   */
  attachToPage() {
    document.body.appendChild(this.container);
  }
  /**
   * 更新索引显示
   */
  updateDisplay() {
    if (this.totalCount === 0) {
      this.indexDisplay.textContent = "\u52A0\u8F7D\u4E2D...";
      this.prevButton.disabled = true;
      this.nextButton.disabled = true;
      this.prevButton.style.opacity = "0.5";
      this.nextButton.style.opacity = "0.5";
      this.prevButton.style.cursor = "not-allowed";
      this.nextButton.style.cursor = "not-allowed";
    } else {
      this.indexDisplay.textContent = `${this.currentIndex + 1} / ${this.totalCount}`;
      this.prevButton.disabled = false;
      this.prevButton.style.opacity = "1";
      this.prevButton.style.cursor = "pointer";
      if (this.currentIndex === 0) {
        this.prevButton.title = this.totalCount === 1 ? "\u6EDA\u52A8\u5230\u9876\u90E8" : "\u5DF2\u7ECF\u662F\u7B2C\u4E00\u6761\uFF08\u70B9\u51FB\u6EDA\u52A8\u5230\u9876\u90E8\uFF09";
      } else {
        this.prevButton.title = this.prevButton.dataset.originalTitle || "\u4E0A\u4E00\u6761\u56DE\u7B54";
      }
      this.nextButton.disabled = this.currentIndex === this.totalCount - 1;
      this.nextButton.style.opacity = this.nextButton.disabled ? "0.5" : "1";
      this.nextButton.style.cursor = this.nextButton.disabled ? "not-allowed" : "pointer";
    }
  }
  /**
   * 更新当前索引和总数
   */
  updateIndex(currentIndex, totalCount) {
    this.currentIndex = currentIndex;
    this.totalCount = totalCount;
    this.updateDisplay();
  }
  /**
   * 注册「上一条」回调
   */
  onPrev(callback) {
    this.onPrevCallback = callback;
  }
  /**
   * 注册「下一条」回调
   */
  onNext(callback) {
    this.onNextCallback = callback;
  }
  /**
   * 显示 UI
   */
  show() {
    this.container.style.opacity = "1";
    this.container.style.pointerEvents = "auto";
  }
  /**
   * 隐藏 UI
   */
  hide() {
    this.container.style.opacity = "0";
    this.container.style.pointerEvents = "none";
  }
  /**
   * 设置加载状态
   */
  setLoading(loading) {
    if (loading) {
      this.indexDisplay.textContent = "\u52A0\u8F7D\u4E2D...";
      this.prevButton.disabled = true;
      this.nextButton.disabled = true;
      this.prevButton.style.opacity = "0.5";
      this.nextButton.style.opacity = "0.5";
      this.prevButton.style.cursor = "not-allowed";
      this.nextButton.style.cursor = "not-allowed";
    } else {
      this.updateDisplay();
    }
  }
  /**
   * 移除 UI
   */
  destroy() {
    this.container.remove();
  }
  /**
   * 加载主题配置
   */
  async loadTheme() {
    try {
      const result = await chrome.storage.sync.get("ui_theme");
      const themeName = result.ui_theme || getDefaultTheme();
      this.setTheme(themeName);
    } catch (error) {
      console.error("\u52A0\u8F7D\u4E3B\u9898\u5931\u8D25:", error);
      this.setTheme(getDefaultTheme());
    }
  }
  /**
   * 设置主题
   */
  setTheme(themeName) {
    const theme = themes[themeName] || themes[getDefaultTheme()];
    this.currentTheme = themeName;
    this.container.style.background = theme.background;
    this.container.style.borderColor = theme.border;
    this.updateButtonTheme(this.prevButton, theme);
    this.updateButtonTheme(this.nextButton, theme);
    if (!this.prevButton.dataset.hoverBound) {
      this.applyButtonHoverEffects(this.prevButton, theme);
      this.applyButtonHoverEffects(this.nextButton, theme);
      this.prevButton.dataset.hoverBound = "true";
      this.nextButton.dataset.hoverBound = "true";
    }
    this.indexDisplay.style.color = theme.textColor;
    console.log(`\u{1F3A8} \u4E3B\u9898\u5DF2\u5207\u6362\u4E3A: ${theme.name}`);
  }
  /**
   * 更新按钮主题
   */
  updateButtonTheme(button, theme) {
    button.style.background = theme.primary;
    button.dataset.primaryColor = theme.primary;
    button.dataset.primaryHover = theme.primaryHover;
  }
  /**
   * 应用按钮主题的 hover 效果
   */
  applyButtonHoverEffects(button, theme) {
    button.addEventListener("mouseenter", () => {
      if (!button.disabled && button.dataset.primaryHover) {
        button.style.background = button.dataset.primaryHover;
        button.dataset.hovered = "true";
        button.style.transform = "scale(1.05)";
      }
    });
    button.addEventListener("mouseleave", () => {
      if (button.dataset.primaryColor) {
        button.style.background = button.dataset.primaryColor;
      }
      button.dataset.hovered = "false";
      button.style.transform = "scale(1)";
    });
    button.addEventListener("mousedown", () => {
      if (!button.disabled) {
        button.style.transform = "scale(0.95)";
      }
    });
    button.addEventListener("mouseup", () => {
      if (!button.disabled && button.dataset.hovered === "true") {
        button.style.transform = "scale(1.05)";
      }
    });
  }
  /**
   * 切换显示/隐藏
   */
  toggle() {
    this.isHidden = !this.isHidden;
    if (this.isHidden) {
      this.container.style.opacity = "0";
      this.container.style.pointerEvents = "none";
      this.container.style.transform = "translateX(120%)";
      console.log("\u{1F648} \u5BFC\u822A\u9762\u677F\u5DF2\u9690\u85CF");
    } else {
      this.container.style.opacity = "1";
      this.container.style.pointerEvents = "auto";
      this.container.style.transform = "translateX(0)";
      console.log("\u{1F441}\uFE0F \u5BFC\u822A\u9762\u677F\u5DF2\u663E\u793A");
    }
  }
  /**
   * 获取隐藏状态
   */
  getHiddenState() {
    return this.isHidden;
  }
};

// src/content/navigation/scrollAndHighlight.ts
var HIGHLIGHT_CLASS = "llm-answer-nav-highlight";
var currentHighlightedNode = null;
var stylesInjected = false;
var currentTheme = getDefaultTheme();
async function injectStyles() {
  try {
    const result = await chrome.storage.sync.get("ui_theme");
    currentTheme = result.ui_theme || getDefaultTheme();
  } catch (error) {
    console.error("\u52A0\u8F7D\u4E3B\u9898\u5931\u8D25:", error);
  }
  const theme = themes[currentTheme];
  const oldStyle = document.getElementById("llm-answer-nav-styles");
  if (oldStyle) {
    oldStyle.remove();
  }
  const style = document.createElement("style");
  style.id = "llm-answer-nav-styles";
  style.textContent = `
    .${HIGHLIGHT_CLASS} {
      position: relative;
      animation: llm-nav-highlight-pulse 1s ease-in-out;
    }
    
    .${HIGHLIGHT_CLASS}::before {
      content: '';
      position: absolute;
      top: -8px;
      left: -8px;
      right: -8px;
      bottom: -8px;
      border: 3px solid ${theme.highlightBorder};
      border-radius: 8px;
      pointer-events: none;
      animation: llm-nav-border-fade 2s ease-in-out forwards;
    }
    
    @keyframes llm-nav-highlight-pulse {
      0%, 100% {
        background-color: transparent;
      }
      50% {
        background-color: ${theme.highlightBackground};
      }
    }
    
    @keyframes llm-nav-border-fade {
      0% {
        opacity: 1;
        border-width: 3px;
      }
      100% {
        opacity: 0.3;
        border-width: 2px;
      }
    }
  `;
  document.head.appendChild(style);
  stylesInjected = true;
}
function scrollToAnswer(node, topOffset = 80) {
  if (!node) {
    console.warn("\u26A0\uFE0F scrollToAnswer: \u8282\u70B9\u4E3A\u7A7A");
    return;
  }
  console.log("\u{1F4CD} \u6EDA\u52A8\u5230\u56DE\u7B54\u8282\u70B9:", {
    tag: node.tagName,
    text: node.textContent?.substring(0, 50) + "...",
    offsetTop: node.offsetTop
  });
  try {
    node.scrollIntoView({
      behavior: "smooth",
      block: "start",
      inline: "nearest"
    });
    setTimeout(() => {
      const currentScroll = window.scrollY;
      if (currentScroll > topOffset) {
        window.scrollTo({
          top: currentScroll - topOffset,
          behavior: "smooth"
        });
      }
    }, 100);
    console.log("\u2705 \u6EDA\u52A8\u547D\u4EE4\u5DF2\u6267\u884C");
  } catch (error) {
    console.error("\u274C \u6EDA\u52A8\u5931\u8D25:", error);
    try {
      const rect = node.getBoundingClientRect();
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const targetPosition = rect.top + scrollTop - topOffset;
      window.scrollTo({
        top: targetPosition,
        behavior: "smooth"
      });
      console.log("\u2705 \u4F7F\u7528\u5907\u7528\u6EDA\u52A8\u65B9\u6CD5");
    } catch (backupError) {
      console.error("\u274C \u5907\u7528\u6EDA\u52A8\u4E5F\u5931\u8D25:", backupError);
    }
  }
}
async function highlightAnswer(node) {
  if (!node)
    return;
  await injectStyles();
  if (currentHighlightedNode && currentHighlightedNode !== node) {
    removeHighlight(currentHighlightedNode);
  }
  node.classList.add(HIGHLIGHT_CLASS);
  currentHighlightedNode = node;
  setTimeout(() => {
  }, 2e3);
}
function removeHighlight(node) {
  if (!node)
    return;
  node.classList.remove(HIGHLIGHT_CLASS);
}
function scrollToAndHighlight(node, topOffset = 80) {
  if (!node)
    return;
  scrollToAnswer(node, topOffset);
  setTimeout(() => {
    highlightAnswer(node);
  }, 300);
}

// src/content/index.ts
console.log("LLM Answer Navigator: Content script loaded");
var indexManager = null;
var navigatorUI = null;
var isInitializing = false;
function debounce(func, wait) {
  let timeout = null;
  return function(...args) {
    if (timeout)
      clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}
function navigateToAnswer(index) {
  if (!indexManager) {
    console.warn("\u26A0\uFE0F indexManager \u672A\u521D\u59CB\u5316");
    return;
  }
  indexManager.setCurrentIndex(index);
  const node = indexManager.getCurrentNode();
  console.log(`\u{1F3AF} \u5BFC\u822A\u5230\u7B2C ${index + 1}/${indexManager.getTotalCount()} \u4E2A\u56DE\u7B54`);
  if (node) {
    console.log("\u2705 \u627E\u5230\u76EE\u6807\u8282\u70B9\uFF0C\u5F00\u59CB\u6EDA\u52A8\u548C\u9AD8\u4EAE");
    scrollToAndHighlight(node);
  } else {
    console.error("\u274C \u672A\u627E\u5230\u76EE\u6807\u8282\u70B9");
  }
  updateUI();
}
function navigateToPrev() {
  console.log("\u2B06\uFE0F \u89E6\u53D1\uFF1A\u4E0A\u4E00\u6761\u56DE\u7B54");
  if (!indexManager || indexManager.getTotalCount() === 0) {
    console.log("\u26A0\uFE0F \u6CA1\u6709\u53EF\u5BFC\u822A\u7684\u56DE\u7B54");
    return;
  }
  if (indexManager.getCurrentIndex() === 0) {
    console.log("\u{1F4CD} \u5DF2\u7ECF\u662F\u7B2C\u4E00\u6761\uFF0C\u6EDA\u52A8\u5230\u9876\u90E8");
    const node = indexManager.getCurrentNode();
    if (node) {
      scrollToAndHighlight(node);
    }
  } else {
    if (indexManager.moveToPrev()) {
      navigateToAnswer(indexManager.getCurrentIndex());
    }
  }
}
function navigateToNext() {
  console.log("\u2B07\uFE0F \u89E6\u53D1\uFF1A\u4E0B\u4E00\u6761\u56DE\u7B54");
  if (!indexManager || indexManager.getTotalCount() === 0) {
    console.log("\u26A0\uFE0F \u6CA1\u6709\u53EF\u5BFC\u822A\u7684\u56DE\u7B54");
    return;
  }
  if (indexManager.moveToNext()) {
    navigateToAnswer(indexManager.getCurrentIndex());
  } else {
    console.log("\u2139\uFE0F \u5DF2\u7ECF\u662F\u6700\u540E\u4E00\u6761\u56DE\u7B54");
  }
}
function updateUI() {
  if (navigatorUI && indexManager) {
    navigatorUI.updateIndex(
      indexManager.getCurrentIndex(),
      indexManager.getTotalCount()
    );
  }
}
var handleScroll = debounce(() => {
  if (indexManager) {
    indexManager.updateCurrentIndexByScroll(window.scrollY);
    updateUI();
  }
}, 200);
async function init() {
  if (isInitializing) {
    console.log("\u23F3 \u6B63\u5728\u521D\u59CB\u5316\u4E2D\uFF0C\u8DF3\u8FC7\u91CD\u590D\u8C03\u7528");
    return;
  }
  isInitializing = true;
  try {
    const adapter = getActiveAdapter(window.location);
    if (!adapter) {
      console.log("LLM Answer Navigator: \u5F53\u524D\u9875\u9762\u4E0D\u652F\u6301\uFF0C\u8DF3\u8FC7\u521D\u59CB\u5316");
      isInitializing = false;
      return;
    }
    console.log(`LLM Answer Navigator: ${adapter.name} \u9875\u9762\u5DF2\u68C0\u6D4B\u5230\uFF0C\u51C6\u5907\u521D\u59CB\u5316`);
    try {
      const result = await chrome.storage.sync.get("enable_chatgpt");
      const isEnabled = result.enable_chatgpt !== false;
      if (!isEnabled) {
        console.log("LLM Answer Navigator: ChatGPT \u5BFC\u822A\u529F\u80FD\u5DF2\u5728\u8BBE\u7F6E\u4E2D\u5173\u95ED");
        isInitializing = false;
        return;
      }
    } catch (error) {
      console.error("\u8BFB\u53D6\u914D\u7F6E\u5931\u8D25:", error);
    }
    if (!navigatorUI) {
      navigatorUI = new NavigatorUI();
      navigatorUI.onPrev(navigateToPrev);
      navigatorUI.onNext(navigateToNext);
    }
    navigatorUI.setLoading(true);
    indexManager = new AnswerIndexManager(adapter, document);
    const totalCount = indexManager.getTotalCount();
    console.log(`LLM Answer Navigator: \u521D\u59CB\u5316\u5B8C\u6210\uFF0C\u5171 ${totalCount} \u4E2A\u56DE\u7B54`);
    if (totalCount > 0) {
      indexManager.updateCurrentIndexByScroll(window.scrollY);
      console.log(`\u{1F4CD} \u521D\u59CB\u4F4D\u7F6E: \u7B2C ${indexManager.getCurrentIndex() + 1}/${totalCount} \u4E2A\u56DE\u7B54`);
    }
    navigatorUI.setLoading(false);
    updateUI();
    if (totalCount === 0) {
      console.warn("\u26A0\uFE0F \u672A\u627E\u5230\u4EFB\u4F55\u56DE\u7B54\uFF0C\u8BF7\u68C0\u67E5\u9875\u9762\u662F\u5426\u5DF2\u52A0\u8F7D\u5B8C\u6210");
    }
    window.addEventListener("scroll", handleScroll, { passive: true });
    const observer = new MutationObserver(debounce(() => {
      if (indexManager && indexManager.needsRefresh()) {
        console.log("\u{1F504} \u68C0\u6D4B\u5230\u9875\u9762\u53D8\u5316\uFF0C\u5237\u65B0\u56DE\u7B54\u5217\u8868");
        indexManager.refresh();
        indexManager.updateCurrentIndexByScroll(window.scrollY);
        updateUI();
      }
    }, 1e3));
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  } finally {
    isInitializing = false;
  }
}
var lastUrl = window.location.href;
var urlObserver = new MutationObserver(() => {
  const currentUrl = window.location.href;
  if (currentUrl !== lastUrl) {
    console.log("\u{1F504} \u68C0\u6D4B\u5230 URL \u53D8\u5316\uFF0C\u91CD\u65B0\u521D\u59CB\u5316");
    lastUrl = currentUrl;
    if (navigatorUI) {
      navigatorUI.setLoading(true);
    }
    setTimeout(() => {
      init();
    }, 1e3);
  }
});
urlObserver.observe(document.documentElement, {
  childList: true,
  subtree: true
});
window.addEventListener("popstate", () => {
  console.log("\u{1F504} \u68C0\u6D4B\u5230\u6D4F\u89C8\u5668\u5BFC\u822A\uFF0C\u91CD\u65B0\u521D\u59CB\u5316");
  setTimeout(() => {
    init();
  }, 500);
});
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Message received in content script:", message);
  if (message.type === "LLM_NAV_PREV_ANSWER") {
    console.log("\u5FEB\u6377\u952E\u89E6\u53D1\uFF1A\u5BFC\u822A\u5230\u4E0A\u4E00\u6761\u56DE\u7B54");
    navigateToPrev();
    sendResponse({ success: true });
  } else if (message.type === "LLM_NAV_NEXT_ANSWER") {
    console.log("\u5FEB\u6377\u952E\u89E6\u53D1\uFF1A\u5BFC\u822A\u5230\u4E0B\u4E00\u6761\u56DE\u7B54");
    navigateToNext();
    sendResponse({ success: true });
  } else if (message.type === "LLM_NAV_TOGGLE_UI") {
    console.log("\u5FEB\u6377\u952E\u89E6\u53D1\uFF1A\u5207\u6362\u5BFC\u822A\u9762\u677F\u663E\u793A");
    if (navigatorUI) {
      navigatorUI.toggle();
      sendResponse({ success: true, hidden: navigatorUI.getHiddenState() });
    } else {
      sendResponse({ success: false, error: "UI not initialized" });
    }
  } else if (message.type === "LLM_NAV_THEME_CHANGED") {
    console.log("\u4E3B\u9898\u5DF2\u66F4\u6539:", message.theme);
    if (navigatorUI) {
      navigatorUI.setTheme(message.theme);
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false, error: "UI not initialized" });
    }
  }
  return true;
});
